Vector3d v(1,2,3);
v.array() += 3;
v.array() -= 2;
cout << v << endl;
